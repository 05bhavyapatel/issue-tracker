package com.bhavya.Tracker.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrackerSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
